import express from "express";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

if (!process.env.OPENAI_API_KEY) {
  console.warn("⚠️ OPENAI_API_KEY n'est pas configurée dans .env");
}

const app = express();
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json({ limit: "1mb" }));
app.use(express.static(__dirname));

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "Message vide." });
    if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: "OPENAI_API_KEY manquante dans le fichier .env." });

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      instructions: `Tu es DRACO AI 🐉, un assistant moderne, amical et utile. Réponds principalement en français sauf si l'utilisateur demande une autre langue. Tu peux aider avec Roblox Studio, Lua, HTML, CSS, JavaScript, Python et d'autres sujets de programmation. Quand l'utilisateur demande du code, donne du code complet et explique où le placer si nécessaire. Ne prétends jamais avoir exécuté ou testé du code si tu ne l'as pas fait. Reste adapté à un public adolescent et refuse brièvement les demandes dangereuses ou interdites.`,
      input: message
    });

    res.json({ reply: response.output_text || "Je n'ai pas pu générer de réponse." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error?.message || "Erreur pendant la génération." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  console.log(`🐉 DRACO AI lancé sur http://localhost:${port}`);
});
