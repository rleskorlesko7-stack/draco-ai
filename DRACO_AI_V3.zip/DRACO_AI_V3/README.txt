DRACO AI V3 🐉

1. Installe Node.js si besoin.
2. Ouvre un terminal dans ce dossier.
3. Lance : npm install
4. Copie .env.example en .env
5. Mets ta clé API OpenAI dans .env : OPENAI_API_KEY=...
6. Lance : npm start
7. Ouvre http://localhost:3000

IMPORTANT : ne mets jamais ta clé API dans index.html et ne partage pas ton fichier .env.

DRACO utilise le Responses API via le SDK officiel OpenAI côté serveur.
